/**
 * 
 */
/**
 * 
 */
module testeCharts {
	requires java.desktop;
}