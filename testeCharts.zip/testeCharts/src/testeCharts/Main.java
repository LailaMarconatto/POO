package testeCharts;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.awt.Desktop;

public class Main {

    public static void main(String[] args) throws IOException {

        File arquivo = new File("relatorio.html");

        // Verifica se o arquivo já existe
        if (arquivo.exists()) {
            System.out.println("Arquivo já gerado anteriormente.");
            System.out.println("Última modificação: " + new Date(arquivo.lastModified()));
        }

        List<Produto> produtos = new ArrayList<>();
        Random random = new Random();

        String[] marcas = {"Kingston","Corsair","Crucial","HyperX","Samsung","ADATA"};
        String[] ddrs = {"DDR3","DDR4","DDR5"};
        String[] categorias = {"PC","Notebook"};

        for(int i = 1; i <= 10000; i++){

            String marca = marcas[random.nextInt(marcas.length)];
            String ddr = ddrs[random.nextInt(ddrs.length)];
            String categoria = categorias[random.nextInt(categorias.length)];

            double preco = 100 + random.nextDouble() * 900;

            produtos.add(new Produto(
                    i,
                    "Memoria " + ddr + " MHz",
                    preco,
                    marca,
                    categoria,
                    ddr
            ));
        }

        // Gera o HTML
        HtmlView.gerarHtml(produtos);

        System.out.println("Relatório gerado com sucesso!");

        // Abre automaticamente no navegador
        if (Desktop.isDesktopSupported()) {
            Desktop.getDesktop().browse(arquivo.toURI());
        }
    }
}